#!/usr/bin/python
#
# Script to show the skeinforge dialog.
#
# Usage: set the executable property to true if it isn't already.  Then double click the file.
#
import skeinforge
skeinforge.main()
